from setuptools import setup

setup(
   name='saveAndLoad',
   version='0.0.1',
   packages=['saveAndLoad'],
   description='This is Numpy Load and Save',
) 